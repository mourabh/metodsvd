import React from 'react';
import { Gift, Eye, TrendingUp, Bot, Search } from 'lucide-react';

export default function Bonus() {
  const bonuses = [
    {
      icon: Eye,
      title: "Espionagem de Anúncios da Concorrência",
      description: "Descubra exatamente o que seus concorrentes estão fazendo que funciona e replique as estratégias vencedoras no seu negócio",
      color: "from-[#875CFF] to-[#F34A9C]"
    },
    {
      icon: TrendingUp,
      title: "Funil de Vendas Secreto para Escalar no Automático",
      description: "Sistema comprovado que funciona 24/7, convertendo visitantes em clientes mesmo enquanto você dorme",
      color: "from-[#3CABAB] to-[#2D6FF6]"
    },
    {
      icon: Bot,
      title: "Inteligência Artificial Aplicada ao Marketing",
      description: "Use IA para criar textos persuasivos, otimizar campanhas e gerar criativos que convertem mais",
      color: "from-[#FF8B3D] to-[#FFD025]"
    },
    {
      icon: Search,
      title: "Análise Personalizada do Seu Funil Atual",
      description: "Auditoria completa e detalhada do seu negócio com pontos específicos de melhoria e oportunidades",
      color: "from-[#C1FF4E] to-[#00F6C8]"
    }
  ];

  return (
    <section className="py-20 bg-black">
      <div className="container mx-auto px-6">
        <div className="text-center mb-16">
          <div className="inline-flex items-center gap-2 bg-gradient-to-r from-[#875CFF] to-[#F34A9C] text-white px-6 py-3 rounded-full text-sm font-semibold mb-6">
            <Gift className="w-5 h-5" />
            Bônus Exclusivos
          </div>
          
          <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold text-white mb-6">
            <span className="bg-gradient-to-r from-[#875CFF] to-[#F34A9C] bg-clip-text text-transparent">
              Bônus Exclusivos
            </span>
          </h2>
          <p className="text-lg md:text-xl text-gray-300 max-w-3xl mx-auto">
            Materiais extras que vão acelerar ainda mais seus resultados
          </p>
        </div>
        
        <div className="grid md:grid-cols-2 gap-8">
          {bonuses.map((bonus, index) => (
            <div key={index} className="group relative stagger-animation">
              <div className="bg-gradient-to-br from-[#0E0E0F] to-black p-8 rounded-3xl border border-gray-800 hover:border-gray-600 transition-all duration-300 hover-lift">
                <div className="flex items-start gap-6">
                  <div className={`w-16 h-16 bg-gradient-to-r ${bonus.color} rounded-2xl flex items-center justify-center flex-shrink-0 group-hover:scale-110 transition-transform duration-300 animate-bounce-slow`}>
                    <bonus.icon className="w-8 h-8 text-black" />
                  </div>
                  
                  <div className="space-y-3">
                    <h3 className="text-base md:text-xl font-bold text-white leading-tight">{bonus.title}</h3>
                    <p className="text-gray-300 leading-relaxed text-xs md:text-sm">{bonus.description}</p>
                  </div>
                </div>
              </div>
              
              <div className={`absolute inset-0 bg-gradient-to-r ${bonus.color} rounded-3xl blur-xl opacity-0 group-hover:opacity-15 transition-opacity duration-500`}></div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}