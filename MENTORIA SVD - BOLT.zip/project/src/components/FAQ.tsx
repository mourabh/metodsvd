import React, { useState } from 'react';
import { Plus, Minus } from 'lucide-react';

export default function FAQ() {
  const [openIndex, setOpenIndex] = useState<number | null>(0);

  const faqs = [
    {
      question: "Preciso ter experiência com anúncios?",
      answer: "Não! A mentoria é pensada tanto para iniciantes quanto para quem já tentou e não teve resultados. Vou te ensinar desde o básico até estratégias avançadas, sempre de forma prática e aplicável."
    },
    {
      question: "Quanto tempo duram as aulas?",
      answer: "Cada aula tem duração de 1 hora, mas pode se estender um pouco se necessário para esclarecer todas as suas dúvidas. O importante é que você saia com tudo bem claro para implementar."
    },
    {
      question: "As aulas ficam gravadas?",
      answer: "Sim! Todas as aulas ficam gravadas e você recebe o acesso para assistir quantas vezes quiser. Assim você pode revisar o conteúdo sempre que precisar."
    },
    {
      question: "Qual investimento mínimo em mídia paga?",
      answer: "Recomendo começar com pelo menos R$ 30-50 por dia para ter dados suficientes para otimizar. Mas vou te ensinar como começar pequeno e escalar conforme os resultados aparecem."
    },
    {
      question: "Funciona para qualquer negócio?",
      answer: "Sim! O Método SVD funciona para qualquer negócio que precise atrair clientes: profissionais liberais, e-commerce, serviços locais, infoprodutos, etc. Vou adaptar as estratégias para o seu nicho específico."
    },
    {
      question: "Tenho suporte após as aulas?",
      answer: "Depende do plano escolhido. O Plano Intermediário inclui 30 dias de suporte no WhatsApp, e o Plano Avançado inclui 60 dias. Assim você não fica sozinho na implementação."
    }
  ];

  return (
    <section className="py-20 bg-black">
      <div className="container mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold text-white mb-6">
            Perguntas <span className="bg-gradient-to-r from-[#C1FF4E] to-[#00F6C8] bg-clip-text text-transparent">Frequentes</span>
          </h2>
          <p className="text-lg md:text-xl text-gray-300 max-w-3xl mx-auto">
            Tire suas principais dúvidas sobre a mentoria
          </p>
        </div>
        
        <div className="max-w-4xl mx-auto space-y-4">
          {faqs.map((faq, index) => (
            <div key={index} className="bg-gradient-to-br from-[#0E0E0F] to-black border border-gray-800 rounded-2xl overflow-hidden">
              <button
                className="w-full p-6 text-left flex items-center justify-between hover:bg-gray-900/50 transition-colors duration-200"
                onClick={() => setOpenIndex(openIndex === index ? null : index)}
              >
                <h3 className="text-sm md:text-lg font-semibold text-white pr-4">{faq.question}</h3>
                <div className="flex-shrink-0">
                  {openIndex === index ? (
                    <Minus className="w-5 h-5 text-[#C1FF4E]" />
                  ) : (
                    <Plus className="w-5 h-5 text-[#C1FF4E]" />
                  )}
                </div>
              </button>
              
              {openIndex === index && (
                <div className="px-6 pb-6">
                  <div className="border-t border-gray-800 pt-4">
                    <p className="text-gray-300 leading-relaxed text-sm md:text-base">{faq.answer}</p>
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}