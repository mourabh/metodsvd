import React from 'react';
import { Check, Target, BarChart3, Shield, Zap, FileText, Users } from 'lucide-react';

export default function WhatYouLearn() {
  const learnings = [
    {
      icon: Target,
      title: "Criar Anúncios Campeões no Meta Ads e Google Ads",
      description: "Domine as estratégias comprovadas de copywriting, segmentação e criativos que realmente convertem visitantes em clientes pagantes"
    },
    {
      icon: BarChart3,
      title: "Configurar Pixel e Estrutura Completa Sem Erros",
      description: "Setup técnico profissional com pixel do Facebook, Google Analytics, conversões e toda estrutura necessária para máxima performance"
    },
    {
      icon: Zap,
      title: "Interpretar Métricas e Escalar Campanhas Lucrativas",
      description: "Entenda profundamente CTR, CPC, CPA, ROAS, frequência e todas as métricas essenciais para tomar decisões certeiras e escalar com segurança"
    },
    {
      icon: Shield,
      title: "Evitar Bloqueios e Manter Suas Campanhas Sempre Ativas",
      description: "Técnicas avançadas de compliance, políticas das plataformas e estratégias para manter suas campanhas rodando sem interrupções"
    },
    {
      icon: FileText,
      title: "Criar Páginas de Vendas Otimizadas Para Conversão",
      description: "Construa landing pages de alta conversão com copywriting persuasivo, design otimizado e elementos que vendem no automático"
    },
    {
      icon: Users,
      title: "Desenvolver Campanhas de Vendas, Engajamento e Seguidores",
      description: "Crie funis completos e estratégias específicas para cada objetivo: vender produtos, gerar leads qualificados e construir audiência engajada"
    }
  ];

  return (
    <section className="py-20 bg-gradient-to-b from-[#0E0E0F] to-black">
      <div className="container mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold text-white mb-6">
            O que você vai <span className="bg-gradient-to-r from-[#C1FF4E] to-[#00F6C8] bg-clip-text text-transparent">aprender</span>
          </h2>
          <p className="text-lg md:text-xl text-gray-300 max-w-3xl mx-auto">
            Conteúdo prático e aplicável que você pode implementar imediatamente no seu negócio
          </p>
        </div>
        
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {learnings.map((item, index) => (
            <div key={index} className="group relative stagger-animation">
              <div className="bg-gradient-to-br from-[#0E0E0F] to-black p-8 rounded-3xl border border-gray-800 hover:border-[#C1FF4E]/30 transition-all duration-300 h-full hover-lift">
                <div className="flex items-start gap-4">
                  <div className="bg-gradient-to-r from-[#C1FF4E] to-[#00F6C8] p-3 rounded-xl flex-shrink-0 group-hover:scale-110 transition-transform duration-300 animate-float">
                    <item.icon className="w-6 h-6 text-black" />
                  </div>
                  
                  <div className="space-y-3">
                    <div className="flex items-start gap-2">
                      <Check className="w-5 h-5 text-[#C1FF4E] flex-shrink-0 mt-1" />
                      <h3 className="text-base md:text-lg font-bold text-white leading-tight">{item.title}</h3>
                    </div>
                    <p className="text-gray-300 text-xs md:text-sm leading-relaxed">{item.description}</p>
                  </div>
                </div>
              </div>
              
              <div className="absolute inset-0 bg-gradient-to-r from-[#C1FF4E] to-[#00F6C8] rounded-3xl blur-xl opacity-0 group-hover:opacity-10 transition-opacity duration-500"></div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}