import React from 'react';
import { Check, Star, Zap } from 'lucide-react';

export default function Pricing() {
  const plans = [
    {
      name: "SVD Starter",
      price: "497",
      popular: false,
      features: [
        "1 Aula Particular (1h) ao vivo no Google Meet",
        "Encontro individual focado no seu negócio",
        "Aprenda a Planejar, Criar e Otimizar campanhas lucrativas",
        "Espaço para responder todas as suas dúvidas",
        "Checklists e guias práticos para aplicação imediata",
        "Gravação da aula para assistir quantas vezes quiser"
      ],
      color: "from-[#3CABAB] to-[#2D6FF6]",
      buttonText: "Escolher Plano",
      link: "https://payment.ticto.app/O93FA7033"
    },
    {
      name: "SVD Pro",
      price: "2.997",
      popular: true,
      features: [
        "3 Aulas Particulares (1h cada) ao vivo no Google Meet",
        "Suporte por 30 Dias no WhatsApp",
        "Encontro individual focado no seu negócio",
        "Aprenda a Planejar, Criar e Otimizar campanhas lucrativas",
        "Espaço para responder todas as suas dúvidas",
        "Checklists, guias e templates prontos para aplicar",
        "Gravação das aulas para assistir quantas vezes quiser",
        "Estratégias de Escala e Remarketing",
        "Bônus Exclusivos inclusos"
      ],
      color: "from-[#C1FF4E] to-[#00F6C8]",
      buttonText: "Escolher Plano",
      link: "https://payment.ticto.app/O049C9410"
    },
    {
      name: "SVD Master",
      price: "4.997",
      popular: false,
      features: [
        "5 Aulas Particulares (1h cada) ao vivo no Google Meet",
        "Suporte por 60 Dias no WhatsApp",
        "Encontro individual focado no seu negócio",
        "Aprenda a Planejar, Criar e Otimizar campanhas lucrativas",
        "Aprenda a ler métricas: CTR, CPC, CPA, ROAS etc",
        "Espaço para responder todas as suas dúvidas",
        "Checklists, guias e templates prontos para aplicar",
        "Gravação das aulas para assistir quantas vezes quiser",
        "Estratégias de Escala e Remarketing",
        "Todos os Bônus Exclusivos inclusos"
      ],
      color: "from-[#875CFF] to-[#F34A9C]",
      buttonText: "Escolher Plano",
      link: "https://payment.ticto.app/O9FD0F0AF"
    }
  ];

  return (
    <section className="py-20 bg-gradient-to-b from-black to-[#0E0E0F]">
      <div className="container mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-4xl lg:text-5xl font-bold text-white mb-6">
            Planos de <span className="bg-gradient-to-r from-[#C1FF4E] to-[#00F6C8] bg-clip-text text-transparent">Mentoria</span>
          </h2>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto">
            Escolha o plano ideal para o seu momento e objetivos
          </p>
        </div>
        
        <div className="grid md:grid-cols-3 gap-8 max-w-6xl mx-auto">
          {plans.map((plan, index) => (
            <div key={index} className={`relative ${plan.popular ? 'scale-105 animate-bounce-slow' : ''} stagger-animation`}>
              {plan.popular && (
                <div className="absolute -top-4 left-1/2 transform -translate-x-1/2 z-10 animate-float">
                  <div className="bg-gradient-to-r from-[#C1FF4E] to-[#00F6C8] text-black px-6 py-2 rounded-full text-sm font-bold flex items-center gap-2">
                    <Star className="w-4 h-4" />
                    Mais Popular
                  </div>
                </div>
              )}
              
              <div className={`bg-gradient-to-br from-[#0E0E0F] to-black p-8 rounded-3xl border-2 ${plan.popular ? 'border-[#C1FF4E] animate-glow' : 'border-gray-800'} hover:border-gray-600 transition-all duration-300 h-full hover-lift`}>
                <div className="text-center mb-8">
                  <h3 className="text-2xl font-bold text-white mb-4">{plan.name}</h3>
                  <div className="mb-6">
                    <span className="text-3xl md:text-4xl lg:text-5xl font-bold text-white">R$ {plan.price}</span>
                    <span className="text-gray-400">,00</span>
                  </div>
                </div>
                
                <div className="space-y-4 mb-8">
                  {plan.features.map((feature, featureIndex) => (
                    <div key={featureIndex} className="flex items-start gap-3">
                      <Check className="w-5 h-5 text-[#C1FF4E] flex-shrink-0 mt-0.5" />
                      <span className="text-gray-300 text-xs md:text-sm leading-relaxed">{feature}</span>
                    </div>
                  ))}
                </div>
                
                <a 
                  href={plan.link}
                  target="_blank"
                  rel="noopener noreferrer"
                  className={`w-full bg-gradient-to-r ${plan.color} text-black py-3 md:py-4 rounded-2xl font-bold text-base md:text-lg hover:shadow-2xl transition-all duration-300 transform hover:scale-110 flex items-center justify-center gap-2 hover-lift ${plan.popular ? 'animate-glow' : ''}`}
                >
                  {plan.popular && <Zap className="w-5 h-5" />}
                  {plan.buttonText}
                </a>
              </div>
              
              <div className={`absolute inset-0 bg-gradient-to-r ${plan.color} rounded-3xl blur-xl opacity-0 hover:opacity-15 transition-opacity duration-500`}></div>
            </div>
          ))}
        </div>
        
        <div className="text-center mt-12">
          <p className="text-gray-400 mb-4">💳 Parcelamento disponível em até 12x</p>
          <p className="text-sm text-gray-500">Todos os planos incluem garantia incondicional de 7 dias</p>
        </div>
      </div>
    </section>
  );
}