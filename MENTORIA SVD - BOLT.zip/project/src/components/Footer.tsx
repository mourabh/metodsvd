import React from 'react';
import { Instagram } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="bg-black border-t border-gray-800 py-12">
      <div className="container mx-auto px-6">
        <div className="grid md:grid-cols-2 gap-8 items-center">
          {/* Brand Info */}
          <div className="space-y-4 text-center md:text-left">
            <div className="flex items-center justify-center md:justify-start gap-3 mb-4">
              <img 
                src="/logo-svd.svg" 
                alt="Método SVD Logo" 
                className="h-12 w-auto"
              />
            </div>
            <p className="text-gray-400 text-sm">
              Método SVD - Transformando negócios através do marketing digital
            </p>
          </div>
          
          {/* Social Links */}
          <div className="flex justify-center md:justify-end">
            <div className="flex items-center gap-4">
              <a href="https://instagram.com/jadermouraoficial" target="_blank" rel="noopener noreferrer" className="w-10 h-10 bg-gradient-to-r from-[#C1FF4E] to-[#00F6C8] rounded-full flex items-center justify-center hover:scale-110 transition-transform duration-300">
                <Instagram className="w-5 h-5 text-black" />
              </a>
            </div>
          </div>
        </div>
        
        {/* Copyright */}
        <div className="border-t border-gray-800 mt-8 pt-8">
          <div className="text-center">
            <p className="text-gray-400 text-sm">
              © 2024 Método SVD. Todos os direitos reservados.
            </p>
            <p className="text-gray-500 text-xs mt-1">
              Desenvolvido com 💚 por Jader Moura
            </p>
          </div>
        </div>
      </div>
    </footer>
  );
}