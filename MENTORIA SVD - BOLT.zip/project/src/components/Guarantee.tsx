import React from 'react';
import { Shield, Clock, RefreshCw } from 'lucide-react';

export default function Guarantee() {
  return (
    <section className="py-20 bg-gradient-to-b from-[#0E0E0F] to-black">
      <div className="container mx-auto px-6">
        <div className="max-w-4xl mx-auto text-center">
          <div className="inline-flex items-center gap-2 bg-gradient-to-r from-[#3CABAB] to-[#2D6FF6] text-white px-6 py-3 rounded-full font-bold mb-8">
            <Shield className="w-5 h-5" />
            Garantia Incondicional
          </div>
          
          <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold text-white mb-8">
            <span className="bg-gradient-to-r from-[#3CABAB] to-[#2D6FF6] bg-clip-text text-transparent">
              Garantia Incondicional
            </span>
          </h2>
          
          <div className="bg-gradient-to-br from-[#0E0E0F] to-black p-12 rounded-3xl border-2 border-[#3CABAB] relative overflow-hidden">
            <div className="absolute inset-0 bg-gradient-to-r from-[#3CABAB] to-[#2D6FF6] opacity-5"></div>
            
            <div className="relative z-10 space-y-8">
              <div className="w-24 h-24 bg-gradient-to-r from-[#3CABAB] to-[#2D6FF6] rounded-full flex items-center justify-center mx-auto">
                <Shield className="w-12 h-12 text-white" />
              </div>
              
              <div className="space-y-6">
                <p className="text-lg md:text-2xl text-white font-semibold">
                  <span className="text-[#3CABAB]">Garantia de Resultado</span>
                </p>
                
                <p className="text-base md:text-xl text-gray-300 leading-relaxed max-w-3xl mx-auto">
                  Se você colocar em prática tudo que ensinamos e não tiver <strong className="text-[#2D6FF6]">resultado algum</strong>, 
                  devolvemos <strong className="text-[#3CABAB]">100% do valor investido</strong>.
                </p>
              </div>
              
              <div className="grid md:grid-cols-3 gap-8 mt-12">
                <div className="text-center">
                  <Clock className="w-8 h-8 text-[#3CABAB] mx-auto mb-3" />
                  <div className="text-sm md:text-lg font-semibold text-white">Implemente</div>
                  <div className="text-gray-400 text-xs md:text-sm">Tudo que ensinar</div>
                </div>
                
                <div className="text-center">
                  <RefreshCw className="w-8 h-8 text-[#2D6FF6] mx-auto mb-3" />
                  <div className="text-sm md:text-lg font-semibold text-white">Sem Resultado</div>
                  <div className="text-gray-400 text-xs md:text-sm">100% reembolso</div>
                </div>
                
                <div className="text-center">
                  <Shield className="w-8 h-8 text-[#3CABAB] mx-auto mb-3" />
                  <div className="text-sm md:text-lg font-semibold text-white">Garantia Total</div>
                  <div className="text-gray-400 text-xs md:text-sm">Confiamos no método</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}