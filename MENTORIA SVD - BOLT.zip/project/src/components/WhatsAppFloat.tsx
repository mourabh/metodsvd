import React from 'react';
import { MessageCircle } from 'lucide-react';

export default function WhatsAppFloat() {
  const whatsappNumber = "5531989588218";
  const message = "Olá! Tenho interesse na Mentoria SVD. Pode me ajudar?";
  const whatsappUrl = `https://wa.me/${whatsappNumber}?text=${encodeURIComponent(message)}`;

  return (
    <a
      href={whatsappUrl}
      target="_blank"
      rel="noopener noreferrer"
      className="fixed bottom-6 right-6 z-50 group animate-bounce-slow"
    >
      <div className="bg-gradient-to-r from-[#25D366] to-[#128C7E] w-16 h-16 rounded-full flex items-center justify-center shadow-2xl hover:shadow-green-500/25 transition-all duration-300 transform hover:scale-125 animate-pulse hover-lift">
        <MessageCircle className="w-8 h-8 text-white" />
      </div>
      
      {/* Tooltip */}
      <div className="absolute bottom-20 right-0 bg-black text-white px-4 py-2 rounded-lg text-sm whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity duration-300 pointer-events-none">
        Fale comigo no WhatsApp
        <div className="absolute top-full right-4 w-0 h-0 border-l-4 border-r-4 border-t-4 border-transparent border-t-black"></div>
      </div>
    </a>
  );
}