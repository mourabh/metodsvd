import React from 'react';
import { Award, Users, TrendingUp, Target } from 'lucide-react';

export default function About() {
  return (
    <section className="py-20 bg-gradient-to-b from-black to-[#0E0E0F]">
      <div className="container mx-auto px-6">
        <div className="max-w-6xl mx-auto">
          {/* Left - Image */}
          <div className="flex justify-center mb-12 animate-fade-in-scale">
            <div className="w-20 h-20 bg-gradient-to-r from-[#875CFF] to-[#F34A9C] rounded-full flex items-center justify-center animate-float hover-lift">
              <span className="text-4xl font-bold text-white">JM</span>
            </div>
          </div>
          
          {/* Right - Content */}
          <div className="space-y-8 text-center max-w-4xl mx-auto animate-slide-in-up">
            <div className="space-y-4">
              <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold text-white">
                Sobre o <span className="bg-gradient-to-r from-[#C1FF4E] to-[#00F6C8] bg-clip-text text-transparent">Mentor</span>
              </h2>
              
              <p className="text-lg md:text-xl text-gray-300 leading-relaxed max-w-3xl mx-auto">
                Sou <strong className="text-[#C1FF4E]">Jader Moura</strong>, especialista em marketing digital há mais de 7 anos, criador do <strong className="text-[#00F6C8]">Método SVD</strong>.
              </p>
              
              <p className="text-sm md:text-lg text-gray-400 leading-relaxed max-w-3xl mx-auto">
                Já ajudei dezenas de empresários — advogados, dentistas, lojistas e prestadores de serviços — a construírem sistemas simples que geram clientes todos os dias, com previsibilidade.
              </p>
              
              <p className="text-sm md:text-lg text-gray-400 leading-relaxed max-w-3xl mx-auto">
                Minha missão é mostrar como qualquer negócio pode se libertar da dependência de indicação e crescer com <strong className="text-[#3CABAB]">estratégias digitais aplicadas da forma certa</strong>.
              </p>
            </div>
            
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-6 max-w-4xl mx-auto">
              <div className="bg-gradient-to-br from-[#0E0E0F] to-black p-6 rounded-2xl border border-gray-800 hover-lift stagger-animation">
                <Award className="w-8 h-8 text-[#C1FF4E] mb-3" />
                <div className="text-xl md:text-2xl font-bold text-white">7+ Anos</div>
                <div className="text-gray-400 text-xs md:text-sm">Experiência</div>
              </div>
              
              <div className="bg-gradient-to-br from-[#0E0E0F] to-black p-6 rounded-2xl border border-gray-800 hover-lift stagger-animation">
                <Users className="w-8 h-8 text-[#00F6C8] mb-3" />
                <div className="text-xl md:text-2xl font-bold text-white">500+</div>
                <div className="text-gray-400 text-xs md:text-sm">Empresários</div>
              </div>
              
              <div className="bg-gradient-to-br from-[#0E0E0F] to-black p-6 rounded-2xl border border-gray-800 hover-lift stagger-animation">
                <TrendingUp className="w-8 h-8 text-[#875CFF] mb-3" />
                <div className="text-xl md:text-2xl font-bold text-white">98%</div>
                <div className="text-gray-400 text-xs md:text-sm">Satisfação</div>
              </div>
              
              <div className="bg-gradient-to-br from-[#0E0E0F] to-black p-6 rounded-2xl border border-gray-800 hover-lift stagger-animation">
                <Target className="w-8 h-8 text-[#F34A9C] mb-3" />
                <div className="text-xl md:text-2xl font-bold text-white">100%</div>
                <div className="text-gray-400 text-xs md:text-sm">Resultados</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}