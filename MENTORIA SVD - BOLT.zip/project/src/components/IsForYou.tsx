import React from 'react';
import { CheckCircle, XCircle } from 'lucide-react';

export default function IsForYou() {
  const forYou = [
    "Está começando e não sabe por onde iniciar",
    "Já tentou rodar anúncios e não teve retorno",
    "Quer se libertar da dependência de agência",
    "Precisa atrair clientes de forma previsível",
    "Quer aprender com acompanhamento individual"
  ];

  const notForYou = [
    "Busca fórmulas mágicas sem esforço",
    "Não tem tempo para implementar",
    "Quer resultados sem investir em mídia",
    "Não está disposto a aprender"
  ];

  return (
    <section className="py-20 bg-[#0E0E0F]">
      <div className="container mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold text-white mb-6">
            Essa mentoria é <span className="bg-gradient-to-r from-[#C1FF4E] to-[#00F6C8] bg-clip-text text-transparent">para você</span> se...
          </h2>
        </div>
        
        <div className="grid lg:grid-cols-2 gap-12 max-w-6xl mx-auto">
          {/* Para Você */}
          <div className="space-y-6">
            <div className="text-center mb-8">
              <div className="inline-flex items-center gap-2 bg-gradient-to-r from-[#C1FF4E] to-[#00F6C8] text-black px-6 py-3 rounded-full font-bold mb-4">
                <CheckCircle className="w-5 h-5" />
                É PARA VOCÊ
              </div>
            </div>
            
            <div className="space-y-4">
              {forYou.map((item, index) => (
                <div key={index} className="flex items-start gap-4 bg-gradient-to-br from-black to-[#0E0E0F] p-6 rounded-2xl border border-gray-800">
                  <CheckCircle className="w-6 h-6 text-[#C1FF4E] flex-shrink-0 mt-1" />
                  <span className="text-white text-sm md:text-lg">{item}</span>
                </div>
              ))}
            </div>
          </div>
          
          {/* Não é Para Você */}
          <div className="space-y-6">
            <div className="text-center mb-8">
              <div className="inline-flex items-center gap-2 bg-gradient-to-r from-[#FF6B6B] to-[#FF8E8E] text-white px-6 py-3 rounded-full font-bold mb-4">
                <XCircle className="w-5 h-5" />
                NÃO É PARA VOCÊ
              </div>
            </div>
            
            <div className="space-y-4">
              {notForYou.map((item, index) => (
                <div key={index} className="flex items-start gap-4 bg-gradient-to-br from-black to-[#0E0E0F] p-6 rounded-2xl border border-gray-800 opacity-60">
                  <XCircle className="w-6 h-6 text-[#FF6B6B] flex-shrink-0 mt-1" />
                  <span className="text-gray-400 text-sm md:text-lg">{item}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}