import React from 'react';
import { Briefcase, GraduationCap, Store, Users } from 'lucide-react';

export default function ForWho() {
  const profiles = [
    {
      icon: Briefcase,
      title: "Empresário",
      description: "Quer escalar seu negócio e ter previsibilidade de vendas",
      color: "from-[#C1FF4E] to-[#00F6C8]"
    },
    {
      icon: GraduationCap,
      title: "Profissional Liberal",
      description: "Precisa de clientes todos os dias de forma consistente",
      color: "from-[#875CFF] to-[#F34A9C]"
    },
    {
      icon: Store,
      title: "Negócio Local",
      description: "Quer dominar o mercado da sua região",
      color: "from-[#3CABAB] to-[#2D6FF6]"
    },
    {
      icon: Users,
      title: "Prestador de Serviços",
      description: "Quer vender mais sem depender de agência",
      color: "from-[#FF8B3D] to-[#FFD025]"
    }
  ];

  return (
    <section className="py-20 bg-[#0E0E0F]">
      <div className="container mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold text-white mb-6">
            <span className="bg-gradient-to-r from-[#C1FF4E] to-[#00F6C8] bg-clip-text text-transparent">
              Mentoria Individualizada
            </span>
          </h2>
          <p className="text-lg md:text-xl text-gray-300 max-w-3xl mx-auto">
            Essa mentoria é para você que busca resultados reais e quer aprender com acompanhamento personalizado
          </p>
        </div>
        
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {profiles.map((profile, index) => (
            <div key={index} className="group relative stagger-animation">
              <div className="bg-gradient-to-br from-black to-[#0E0E0F] p-8 rounded-3xl border border-gray-800 hover:border-gray-600 transition-all duration-300 h-full hover-lift">
                <div className={`w-16 h-16 bg-gradient-to-r ${profile.color} rounded-2xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300 animate-bounce-slow`}>
                  <profile.icon className="w-8 h-8 text-black" />
                </div>
                
                <h3 className="text-lg md:text-xl font-bold text-white mb-4">{profile.title}</h3>
                <p className="text-gray-400 leading-relaxed text-sm md:text-base">{profile.description}</p>
              </div>
              
              <div className={`absolute inset-0 bg-gradient-to-r ${profile.color} rounded-3xl blur-xl opacity-0 group-hover:opacity-20 transition-opacity duration-500`}></div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}