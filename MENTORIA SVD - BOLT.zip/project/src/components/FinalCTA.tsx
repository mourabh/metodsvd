import React from 'react';
import { Zap, Clock, TrendingUp } from 'lucide-react';

export default function FinalCTA() {
  return (
    <section className="py-20 bg-gradient-to-br from-black via-[#0E0E0F] to-black relative overflow-hidden">
      {/* Background Effects */}
      <div className="absolute inset-0">
        <div className="absolute top-10 left-10 w-96 h-96 bg-gradient-to-r from-[#C1FF4E] to-[#00F6C8] rounded-full blur-3xl opacity-10 animate-pulse"></div>
        <div className="absolute bottom-10 right-10 w-96 h-96 bg-gradient-to-r from-[#875CFF] to-[#F34A9C] rounded-full blur-3xl opacity-10 animate-pulse delay-1000"></div>
      </div>
      
      <div className="container mx-auto px-6 relative z-10">
        <div className="max-w-5xl mx-auto text-center">
          <div className="space-y-8 mb-12">
            <h2 className="text-4xl lg:text-6xl font-bold text-white leading-tight">
              Não perca mais tempo tentando <span className="bg-gradient-to-r from-[#C1FF4E] to-[#00F6C8] bg-clip-text text-transparent">adivinhar</span> o que funciona
            </h2>
            
            <p className="text-2xl text-gray-300 leading-relaxed max-w-4xl mx-auto">
              Garanta sua vaga na <strong className="text-[#C1FF4E]">Mentoria Exclusiva Método SVD</strong> e monte sua máquina de vendas <strong className="text-[#00F6C8]">ainda esta semana</strong>.
            </p>
          </div>
          
          <div className="grid md:grid-cols-3 gap-8 mb-12">
            <div className="bg-gradient-to-br from-[#0E0E0F] to-black p-8 rounded-3xl border border-gray-800 hover-lift stagger-animation">
              <Clock className="w-12 h-12 text-[#C1FF4E] mx-auto mb-4 animate-float" />
              <h3 className="text-xl font-bold text-white mb-2">Resultados Rápidos</h3>
              <p className="text-gray-400">Monte sua estratégia em apenas 1 dia</p>
            </div>
            
            <div className="bg-gradient-to-br from-[#0E0E0F] to-black p-8 rounded-3xl border border-gray-800 hover-lift stagger-animation">
              <TrendingUp className="w-12 h-12 text-[#00F6C8] mx-auto mb-4 animate-bounce-slow" />
              <h3 className="text-xl font-bold text-white mb-2">Crescimento Previsível</h3>
              <p className="text-gray-400">Clientes todos os dias, sem depender de indicação</p>
            </div>
            
            <div className="bg-gradient-to-br from-[#0E0E0F] to-black p-8 rounded-3xl border border-gray-800 hover-lift stagger-animation">
              <Zap className="w-12 h-12 text-[#875CFF] mx-auto mb-4 animate-float" />
              <h3 className="text-xl font-bold text-white mb-2">Acompanhamento Individual</h3>
              <p className="text-gray-400">Mentoria personalizada para seu negócio</p>
            </div>
          </div>
          
          <div className="space-y-6">
            <a 
              href="https://payment.ticto.app/O049C9410"
              target="_blank"
              rel="noopener noreferrer"
              className="group bg-gradient-to-r from-[#C1FF4E] to-[#00F6C8] text-black px-6 py-3 md:px-8 md:py-4 rounded-full font-bold text-base md:text-lg hover:shadow-2xl hover:shadow-[#C1FF4E]/25 transition-all duration-300 transform hover:scale-110 inline-flex items-center gap-2 animate-glow hover-lift"
            >
              <Zap className="w-5 h-5 md:w-6 md:h-6" />
              🔥 Quero começar agora
            </a>
            
            <div className="flex items-center justify-center gap-8 text-sm text-gray-400">
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 bg-[#C1FF4E] rounded-full"></div>
                Garantia de 7 dias
              </div>
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 bg-[#00F6C8] rounded-full"></div>
                Suporte incluso
              </div>
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 bg-[#875CFF] rounded-full"></div>
                Parcelamento disponível
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}