import React from 'react';
import { Star } from 'lucide-react';

export default function Hero() {
  return (
    <section className="relative min-h-screen bg-gradient-to-br from-black via-gray-900 to-black overflow-hidden">
      {/* Background Effects */}
      <div className="absolute inset-0">
        <div className="absolute top-20 left-10 w-72 h-72 bg-gradient-to-r from-[#C1FF4E] to-[#00F6C8] rounded-full blur-3xl opacity-20 animate-pulse"></div>
        <div className="absolute bottom-20 right-10 w-96 h-96 bg-gradient-to-r from-[#875CFF] to-[#F34A9C] rounded-full blur-3xl opacity-15 animate-pulse delay-1000"></div>
      </div>

      <div className="relative z-10 container mx-auto px-6 py-20">
        <div className="grid lg:grid-cols-2 gap-12 items-center min-h-screen">
          {/* Left Content */}
          <div className="space-y-8 animate-slide-in-left">
            {/* Logo SVD */}
            <div className="flex justify-center lg:justify-start mb-8 -mt-12">
              <img 
                src="/logo-svd.svg" 
                alt="SVD Logo" 
                className="h-24 w-auto animate-fade-in-scale"
              />
            </div>
            
            <div className="inline-flex items-center gap-2 bg-gradient-to-r from-[#C1FF4E] to-[#00F6C8] text-black px-4 py-2 rounded-full text-sm font-semibold animate-bounce-slow">
              <Star className="w-4 h-4" />
              Mentoria Exclusiva
            </div>
            
            <h1 className="text-5xl lg:text-7xl font-bold leading-tight animate-fade-in-scale">
              <span className="text-white">Mentoria Individual</span>
            </h1>
            
            <p className="text-xl text-gray-300 leading-relaxed max-w-2xl animate-slide-in-up">
              Monte sua <strong className="text-[#C1FF4E]">Máquina de Vendas</strong> em apenas 1 dia com acompanhamento individual e aprenda a atrair clientes todos os dias, <strong className="text-[#00F6C8]">sem depender de indicação</strong>.
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4">
              <a 
                href="https://payment.ticto.app/O049C9410"
                target="_blank"
                rel="noopener noreferrer"
                className="group bg-gradient-to-r from-[#C1FF4E] to-[#00F6C8] text-black px-6 py-3 md:px-8 md:py-4 rounded-full font-bold text-sm md:text-base hover:shadow-2xl hover:shadow-[#C1FF4E]/25 transition-all duration-300 transform hover:scale-110 text-center animate-glow hover-lift"
              >
                🔥 Quero minha vaga agora
              </a>
            </div>
            
            <div className="flex items-center gap-8 pt-8">
              <div className="text-center">
                <div className="text-3xl font-bold text-[#C1FF4E] stagger-animation">500+</div>
                <div className="text-gray-400 text-sm">Empresários atendidos</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-[#00F6C8] stagger-animation">7 anos</div>
                <div className="text-gray-400 text-sm">De experiência</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-[#875CFF] stagger-animation">98%</div>
                <div className="text-gray-400 text-sm">Satisfação</div>
              </div>
            </div>
          </div>
          
          {/* Right Content - Mentor Image */}
          <div className="relative">
            <div className="relative z-10 bg-gradient-to-br from-[#0E0E0F] to-black p-4 rounded-3xl border border-gray-800 max-w-xs mx-auto">
              <img 
                src="/Foto Jader Moura.png" 
                alt="Jader Moura - Mentor SVD" 
                className="w-full h-auto rounded-2xl animate-slide-in-right"
              />
              <div className="absolute -top-4 -right-4 bg-gradient-to-r from-[#C1FF4E] to-[#00F6C8] p-4 rounded-full animate-float">
                <Star className="w-6 h-6 text-black" />
              </div>
            </div>
            <div className="absolute inset-0 bg-gradient-to-r from-[#C1FF4E] to-[#00F6C8] rounded-3xl blur-xl opacity-20 animate-pulse"></div>
          </div>
        </div>
      </div>
    </section>
  );
}