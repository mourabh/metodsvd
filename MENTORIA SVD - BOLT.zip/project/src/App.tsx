import React from 'react';
import Hero from './components/Hero';
import About from './components/About';
import ForWho from './components/ForWho';
import WhatYouLearn from './components/WhatYouLearn';
import Bonus from './components/Bonus';
import Pricing from './components/Pricing';
import IsForYou from './components/IsForYou';
import Guarantee from './components/Guarantee';
import FAQ from './components/FAQ';
import FinalCTA from './components/FinalCTA';
import Footer from './components/Footer';
import WhatsAppFloat from './components/WhatsAppFloat';

function App() {
  return (
    <div className="min-h-screen bg-black">
      <Hero />
      <About />
      <ForWho />
      <WhatYouLearn />
      <Bonus />
      <Pricing />
      <IsForYou />
      <Guarantee />
      <FAQ />
      <FinalCTA />
      <Footer />
      <WhatsAppFloat />
    </div>
  );
}

export default App;